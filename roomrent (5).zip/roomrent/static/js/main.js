const date = new Date();
document.querySelector('.year').innerHTML = date.getFullYear();
